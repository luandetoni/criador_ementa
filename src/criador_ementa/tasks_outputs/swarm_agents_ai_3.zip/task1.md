# Pesquisa sobre Swarm Agents A.I.

## Artigos Selecionados

1. **Título**: Swarm Intelligence Layer to Control Autonomous Agents (SWILT)
   - **Autores**: Melanie Schranz, Micha Rappaport, André Breitschopf
   - **Ano de Publicação**: 2020
   - **Periódico**: Frontiers in Robotics and AI
   - **DOI**: https://doi.org/10.3389/frobt.2020.00036
   - **Resumo**: Este artigo propõe uma estrutura de controle em camadas para coordenar o comportamento de um enxame de agentes autônomos. A camada de inteligência de enxame (SWILT) é responsável por organizar as interações entre os agentes de nível inferior, permitindo que eles trabalhem em conjunto de forma eficiente.
   - **Metodologia**: Os autores desenvolveram uma arquitetura multinível com uma camada de inteligência de enxame para coordenar um grupo de agentes robóticos autônomos. Eles realizaram experimentos de simulação e em um cenário real para validar a eficácia da abordagem.
   - **Resultados**: A estrutura SWILT demonstrou capacidade de coordenação eficiente do enxame, permitindo que os agentes realizassem tarefas complexas de forma colaborativa e adaptativa.
   - **Conclusões**: O trabalho apresenta avanços importantes na área de sistemas multiagentes, mostrando como a inteligência de enxame pode ser utilizada para orquestrar o comportamento de agentes autônomos de maneira descentralizada e robusta.
   - **Citações**: 36

2. **Título**: Human-swarm interactions based on managing attractors
   - **Autores**: Daniel S. Brown, Stephanie C. Kerman, Michael A. Goodrich
   - **Ano de Publicação**: 2014
   - **Periódico**: ACM/IEEE International Conference on Human-Robot Interaction (HRI)
   - **DOI**: https://doi.org/10.1145/2559636.2559661
   - **Resumo**: Este trabalho investiga como os seres humanos podem interagir e controlar efetivamente um enxame de agentes robóticos. Os autores propõem uma abordagem baseada no conceito de "atratores" para orientar o comportamento do enxame.
   - **Metodologia**: Os pesquisadores realizaram estudos experimentais com participantes humanos controlando um enxame simulado de robôs. Eles avaliaram diferentes estratégias de interação baseadas no conceito de atratores.
   - **Resultados**: A abordagem de controle de atratores demonstrou ser eficaz, permitindo que os participantes humanos guiassem o enxame de robôs para realizar tarefas de maneira colaborativa.
   - **Conclusões**: O estudo mostra que a interação humano-enxame pode ser facilitada pelo uso de atratores, fornecendo uma interface intuitiva para o controle e a coordenação de sistemas multiagentes complexos.
   - **Citações**: 110

3. **Título**: Adaptable Decentralized Task Allocation of Swarm Agents
   - **Autores**: Vera Kazakova, David St-Onge, Giovanni Beltrame
   - **Ano de Publicação**: 2019
   - **Periódico**: IEEE Transactions on Cognitive and Developmental Systems
   - **DOI**: https://doi.org/10.1109/TCDS.2019.2902179
   - **Resumo**: Este artigo propõe um sistema de alocação de tarefas descentralizado e adaptável para enxames de agentes robóticos. A abordagem permite que os agentes ajustem dinamicamente suas próprias capacidades e responsabilidades em resp