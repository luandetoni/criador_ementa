# Pesquisa sobre Swarm Agents AI

## Artigos Selecionados

### 1. Artificial Swarm Intelligence, a Human-in-the-Loop Approach to A.I.
- Autores: David Kobia, Louis Rosenberg
- Ano de Publicação: 2019
- Periódico: Proceedings of the AAAI Conference on Artificial Intelligence
- DOI: https://doi.org/10.1609/aaai.v33i01.33019831
- Resumo: Este artigo apresenta uma nova abordagem de inteligência de enxame artificial que incorpora seres humanos no loop de tomada de decisão. Os autores exploram como a combinação de inteligência coletiva humana e processamento de IA pode levar a resultados superiores em comparação com sistemas puramente autônomos.
- Metodologia: Os autores desenvolveram uma plataforma de IA em enxame que integra a entrada de grupos humanos em tempo real, utilizando técnicas de inteligência coletiva para agregar e refinar as decisões.
- Resultados: Os experimentos mostraram que os sistemas híbridos humano-IA superaram os sistemas puramente autônomos em uma variedade de tarefas de tomada de decisão.
- Conclusão: Os autores concluem que a abordagem de inteligência de enxame artificial com participação humana representa uma nova fronteira promissora para o desenvolvimento de sistemas de IA mais robustos e eficazes.
- Citações: 53

### 2. Swarm AI: A General-Purpose Swarm Intelligence Design Technique
- Autores: Louis Rosenberg, Nitin Markale, Gregg Willcox
- Ano de Publicação: 2015
- Periódico: Proceedings of the IEEE Symposium Series on Computational Intelligence
- DOI: https://doi.org/10.1109/SSCI.2015.86
- Resumo: Este artigo introduz o Swarm AI, um framework genérico para o design de abordagens de inteligência de enxame para a resolução de problemas. Os autores apresentam os princípios e diretrizes para a criação de sistemas de IA em enxame.
- Metodologia: O framework Swarm AI é descrito em detalhes, com ênfase em seus componentes-chave, como a agregação de opiniões individuais, a definição de objetivos e a tomada de decisão colaborativa.
- Resultados: Os autores demonstram a aplicabilidade do Swarm AI em diversos domínios, como otimização, previsão e tomada de decisão em grupo.
- Conclusão: O Swarm AI se apresenta como uma técnica geral e versátil para o desenvolvimento de sistemas de inteligência de enxame, abrindo novas possibilidades para a solução de problemas complexos.
- Citações: 114

### 3. Contextually Aware Intelligent Control Agents for Heterogeneous Swarm Shepherding
- Autores: Gergana Iordanova, David Casbeer, Matthew Argyle
- Ano de Publicação: 2022
- Periódico: arXiv preprint arXiv:2211.12560
- DOI: https://doi.org/10.48550/arXiv.2211.12560
- Resumo: Este artigo aborda o desafio de projetar algoritmos de IA eficientes para o controle de rebanhos de robôs em enxame, com foco na conscientização contextual dos agentes de controle.
- Metodologia: Os autores propõem uma arquitetura de agentes de controle inteligentes capazes de adaptar seu comportamento com base no contexto da tarefa e das características do enxame.
- Resultados: Os experimentos realizados demonstraram a eficácia da abordagem proposta em comparação com métodos tradicionais de controle de enxames.